﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheckInApp.ServerConfiguration
{
    //Made by Eby
    public class Time
    {
        public string start { get; set; }
        public string timeDesc { get; set; }
        public string end { get; set; }
    }
}
