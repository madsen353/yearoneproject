﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FunHall
{
    public class Product
    {

        public string product { get; set; }
        public string prodAmount { get; set; }
        public string prodPrice { get; set; }
        public string prodTotPrice { get; set; }
    }
}
